即拼原生 Live 示例。每个同名 JPG 与 MOV 是一对资源。Mac：解压后同时将同名两文件拖入“照片”，导入后长按或悬停 LIVE 播放。单独保存 JPG 或网页 MP4 不会成为 Live。iPhone 请在即拼 App 中选择“保存 Live 到相册”。
